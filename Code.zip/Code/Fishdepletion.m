%%%Natural depletion
a=42989
% v=0.117;
u=0.253;
for t=2007:2020
    nat_num(:,t-2006)=a.*(1-u)^(t-2006);
end
time=2006:2020;
f1=figure
scatter(time, [a nat_num], 60, 'filled', 'o', 'MarkerFaceColor', [255 69 0]/255);
[xData, yData] = prepareCurveData( time, [a nat_num]);

% 设置 fittype 和选项。
ft = fittype( 'exp1' );
opts = fitoptions( 'Method', 'NonlinearLeastSquares' );
opts.Display = 'Off';
opts.Normalize = 'on';
opts.StartPoint = [1165.7055197693 -4.38849013057851];
hold on
load pzhykty.mat
% 对数据进行模型拟合。
[fitresult, gof] = fit( xData, yData, ft, opts );
% plot(a,b,'Color','k','LineWidth',2,'LineStyle','-')
h=plot( fitresult, xData, yData);
hold on
c=pzhykty(:,1);
d=pzhykty(:,2);
scatter(c,d,60,'filled', 'o','MarkerFaceColor','b')
boxchi = get(gca, 'Children');
legend([boxchi(2),boxchi(4),boxchi(1)], ["Spawners" 'Simulated result' 'Measurement data'],'FontName', 'Times New Roman', 'Position', [0.4, 0.72, 0.5, 0.1], 'Box', 'on', 'FontSize', 16, 'Orientation', 'horizontal','Color','w' ,'NumColumns',1,'FontWeight','bold');

% pzhykty=unnamed1;
% save pzhykty pzhykty
% c=pzhykty(:,1);
% d=pzhykty(:,2);
% scatter(c,d,60,'filled', 'o','MarkerFaceColor','b')
% boxchi = get(gca, 'Children');
% legend([boxchi(1),boxchi(3)], ["Spawners" 'Simulated result'],'FontName', 'Times New Roman', 'Position', [0.4, 0.72, 0.5, 0.1], 'Box', 'on', 'FontSize', 16, 'Orientation', 'horizontal','Color','w' ,'NumColumns',1,'FontWeight','bold');
set(h,'LineWidth',2,'Marker','none','Color','k')
set(gca,'xlim',[2005 2020],'ylim',[-1000 50000],'xtick',2006:3:2020,'ytick',0:8000:40000,'yticklabel',0:8000:40000,'TickDir','out','XTickLabelRotation',0, 'FontName','Times New Roman','FontSize',18);
set(gca,'linewidth',1)
xlabel('Year','FontWeight','bold')
ylabel('Fish quantity (ind)','FontWeight','bold')
set(gca, 'GridColor', [1 1 1], 'GridAlpha', 1, 'GridLineStyle', '-','linewidth',1);
box off
set(gca,'color',[245 245 245]/255)
grid('on');
ax2 = axes('Position',get(gca,'Position'),...
    'Color','none',...
    'XAxisLocation','top',...
    'YAxisLocation','right',...
    'XColor','k','YColor','k','LineWidth',1);
set(ax2,'YTick', []);
set(ax2,'XTick', []);
f1.InvertHardcopy = 'off';
set(f1,'color','w')
%% fish depletion
a=42989
v=0.117;
% u=0.253;
for t=2007:2020
    ex_num(:,t-2006)=a.*(1-v)^(t-2006);
end
time=2006:2020;
f1=figure
scatter(time, [a ex_num], 60, 'filled', 'o', 'MarkerFaceColor', [255 69 0]/255);
[xData, yData] = prepareCurveData( time, [a ex_num]);

% 设置 fittype 和选项。
ft = fittype( 'exp1' );
opts = fitoptions( 'Method', 'NonlinearLeastSquares' );
opts.Display = 'Off';
opts.Normalize = 'on';
opts.StartPoint = [1165.7055197693 -4.38849013057851];
hold on
% 对数据进行模型拟合。
[fitresult, gof] = fit( xData, yData, ft, opts );
% plot(a,b,'Color','k','LineWidth',2,'LineStyle','-')
h=plot( fitresult, xData, yData);
hold on
c=pzhykty(:,1);
d=pzhykty(:,2);
scatter(c,d,60,'filled', 'o','MarkerFaceColor','b')
boxchi = get(gca, 'Children');
legend([boxchi(2),boxchi(4),boxchi(1)], ["Spawners" 'Simulated result' 'Measurement data'],'FontName', 'Times New Roman', 'Position', [0.4, 0.72, 0.5, 0.1], 'Box', 'on', 'FontSize', 16, 'Orientation', 'horizontal','Color','w' ,'NumColumns',1,'FontWeight','bold');

% pzhykty=unnamed1;
% save pzhykty pzhykty
% c=pzhykty(:,1);
% d=pzhykty(:,2);
% scatter(c,d,60,'filled', 'o','MarkerFaceColor','b')
% boxchi = get(gca, 'Children');
% legend([boxchi(1),boxchi(3)], ["Spawners" 'Simulated result'],'FontName', 'Times New Roman', 'Position', [0.4, 0.72, 0.5, 0.1], 'Box', 'on', 'FontSize', 16, 'Orientation', 'horizontal','Color','w' ,'NumColumns',1,'FontWeight','bold');
set(h,'LineWidth',2,'Marker','none','Color','k')
set(gca,'xlim',[2005 2020],'ylim',[-1000 50000],'xtick',2006:3:2020,'ytick',0:8000:40000,'yticklabel',0:8000:40000,'TickDir','out','XTickLabelRotation',0, 'FontName','Times New Roman','FontSize',18);
set(gca,'linewidth',1)
xlabel('Year','FontWeight','bold')
ylabel('Fish quantity (ind)','FontWeight','bold')
set(gca, 'GridColor', [1 1 1], 'GridAlpha', 1, 'GridLineStyle', '-','linewidth',1);
box off
set(gca,'color',[245 245 245]/255)
grid('on');
ax2 = axes('Position',get(gca,'Position'),...
    'Color','none',...
    'XAxisLocation','top',...
    'YAxisLocation','right',...
    'XColor','k','YColor','k','LineWidth',1);
set(ax2,'YTick', []);
set(ax2,'XTick', []);
f1.InvertHardcopy = 'off';
set(f1,'color','w')
%% dam barrier-induced depletion
a=42989
% v=0.117;
% u=0.253;
for t=2007:2020
     dam_num(:,t-2006)=a.*0.53.^(t-2006);
end
time=2006:2020;
f1=figure
scatter(time, [a dam_num], 60, 'filled', 'o', 'MarkerFaceColor', [255 69 0]/255);
[xData, yData] = prepareCurveData( time, [a dam_num]);

% 设置 fittype 和选项。
ft = fittype( 'exp1' );
opts = fitoptions( 'Method', 'NonlinearLeastSquares' );
opts.Display = 'Off';
opts.Normalize = 'on';
opts.StartPoint = [1165.7055197693 -4.38849013057851];
hold on
% 对数据进行模型拟合。
[fitresult, gof] = fit( xData, yData, ft, opts );
% plot(a,b,'Color','k','LineWidth',2,'LineStyle','-')
h=plot( fitresult, xData, yData);
hold on
c=pzhykty(:,1);
d=pzhykty(:,2);
scatter(c,d,60,'filled', 'o','MarkerFaceColor','b')
boxchi = get(gca, 'Children');
legend([boxchi(2),boxchi(4),boxchi(1)], ["Spawners" 'Simulated result' 'Measurement data'],'FontName', 'Times New Roman', 'Position', [0.4, 0.72, 0.5, 0.1], 'Box', 'on', 'FontSize', 16, 'Orientation', 'horizontal','Color','w' ,'NumColumns',1,'FontWeight','bold');
% pzhykty=unnamed1;
% save pzhykty pzhykty
% c=pzhykty(:,1);
% d=pzhykty(:,2);
% scatter(c,d,60,'filled', 'o','MarkerFaceColor','b')
% boxchi = get(gca, 'Children');
% legend([boxchi(1),boxchi(3)], ["Spawners" 'Simulated result'],'FontName', 'Times New Roman', 'Position', [0.4, 0.72, 0.5, 0.1], 'Box', 'on', 'FontSize', 16, 'Orientation', 'horizontal','Color','w' ,'NumColumns',1,'FontWeight','bold');
set(h,'LineWidth',2,'Marker','none','Color','k')
set(gca,'xlim',[2005 2020],'ylim',[-1000 50000],'xtick',2006:3:2020,'ytick',0:8000:40000,'yticklabel',0:8000:40000,'TickDir','out','XTickLabelRotation',0, 'FontName','Times New Roman','FontSize',18);
set(gca,'linewidth',1)
xlabel('Year','FontWeight','bold')
ylabel('Fish quantity (ind)','FontWeight','bold')
set(gca, 'GridColor', [1 1 1], 'GridAlpha', 1, 'GridLineStyle', '-','linewidth',1);
box off
set(gca,'color',[245 245 245]/255)
grid('on');
ax2 = axes('Position',get(gca,'Position'),...
    'Color','none',...
    'XAxisLocation','top',...
    'YAxisLocation','right',...
    'XColor','k','YColor','k','LineWidth',1);
set(ax2,'YTick', []);
set(ax2,'XTick', []);
f1.InvertHardcopy = 'off';
set(f1,'color','w')
%% 
%%turbine-induced depletion
a=2956
% v=0.117;
% u=0.253;
% a2=b*(0.2)
m=0.2
for t=2011:2020
    slj_num(:,t-2010)=a.*(1-m)^(t-2010);
end

time=2010:2020;
f1=figure
scatter(time, [a slj_num], 60, 'filled', 'o', 'MarkerFaceColor', [255 69 0]/255);
[xData, yData] = prepareCurveData( time, [a slj_num]);

% 设置 fittype 和选项。
ft = fittype( 'exp1' );
opts = fitoptions( 'Method', 'NonlinearLeastSquares' );
opts.Display = 'Off';
opts.Normalize = 'on';
opts.StartPoint = [1165.7055197693 -4.38849013057851];
hold on
% 对数据进行模型拟合。
[fitresult, gof] = fit( xData, yData, ft, opts );
% plot(a,b,'Color','k','LineWidth',2,'LineStyle','-')
h=plot( fitresult, xData, yData);
hold on
load pzhykty.mat
c=pzhykty(:,1);
d=pzhykty(:,2);
scatter(c,d,60,'filled', 'o','MarkerFaceColor','b')
boxchi = get(gca, 'Children');
legend([boxchi(2),boxchi(4),boxchi(1)], ["Spawners" 'Simulated result' 'Measurement data'],'FontName', 'Times New Roman', 'Position', [0.4, 0.72, 0.5, 0.1], 'Box', 'on', 'FontSize', 16, 'Orientation', 'horizontal','Color','w' ,'NumColumns',1,'FontWeight','bold');
% pzhykty=unnamed1;
% save pzhykty pzhykty
% c=pzhykty(:,1);
% d=pzhykty(:,2);
% scatter(c,d,60,'filled', 'o','MarkerFaceColor','b')
% boxchi = get(gca, 'Children');
% legend([boxchi(1),boxchi(3)], ["Spawners" 'Simulated result'],'FontName', 'Times New Roman', 'Position', [0.4, 0.72, 0.5, 0.1], 'Box', 'on', 'FontSize', 16, 'Orientation', 'horizontal','Color','w' ,'NumColumns',1,'FontWeight','bold');
set(h,'LineWidth',2,'Marker','none','Color','k')
set(gca,'xlim',[2009 2020],'ylim',[-500 4000],'xtick',2009:3:2020,'ytick',0:1000:4000,'yticklabel',0:1000:4000,'TickDir','out','XTickLabelRotation',0, 'FontName','Times New Roman','FontSize',18);
set(gca,'linewidth',1)
xlabel('Year','FontWeight','bold')
ylabel('Fish quantity (ind)','FontWeight','bold')
set(gca, 'GridColor', [1 1 1], 'GridAlpha', 1, 'GridLineStyle', '-','linewidth',1);
box off
set(gca,'color',[245 245 245]/255)
grid('on');
ax2 = axes('Position',get(gca,'Position'),...
    'Color','none',...
    'XAxisLocation','top',...
    'YAxisLocation','right',...
    'XColor','k','YColor','k','LineWidth',1);
set(ax2,'YTick', []);
set(ax2,'XTick', []);
f1.InvertHardcopy = 'off';
set(f1,'color','w')
%% Combined impact
a=42989;%%inital value
v=0.117;%%%fishing mortality
u=0.253;%%%natural mortality
m=0.2;%%%turbine mortality
n=0.53;%%dam barrier
for t=2007:2020
    a1(:,t-2006)=a.*n.^(t-2006)*(1-v-u-m);
end
% load pzhyktynum.mat;load pzhykty.mat
% a=pzhyktynum(:,1);
% b=pzhyktynum(:,2);
b=[a a1];
time=2006:2020;
f1=figure
scatter(time, b, 60, 'filled', 'o', 'MarkerFaceColor', [255 69 0]/255);
[xData, yData] = prepareCurveData(time,b);
% 设置 fittype 和选项。
ft = fittype( 'exp1' );
opts = fitoptions( 'Method', 'NonlinearLeastSquares' );
opts.Display = 'Off';
opts.Normalize = 'on';
opts.StartPoint = [1165.7055197693 -4.38849013057851];
hold on
% 对数据进行模型拟合。
[fitresult, gof] = fit( xData, yData, ft, opts );
% plot(a,b,'Color','k','LineWidth',2,'LineStyle','-')
h=plot( fitresult, xData, yData);
hold on
load pzhykty.mat
% pzhykty=unnamed1;
% save pzhykty pzhykty
c=pzhykty(:,1);
d=pzhykty(:,2);
scatter(c,d,60,'filled', 'o','MarkerFaceColor','b')
boxchi = get(gca, 'Children');
legend([boxchi(2),boxchi(4),boxchi(1)], ["Spawners" 'Simulated result' 'Measurement data'],'FontName', 'Times New Roman', 'Position', [0.4, 0.72, 0.5, 0.1], 'Box', 'on', 'FontSize', 16, 'Orientation', 'horizontal','Color','w' ,'NumColumns',1,'FontWeight','bold');
set(h,'LineWidth',2,'Marker','none','Color','k')
set(gca,'xlim',[2005 2020],'ylim',[-1000 50000],'xtick',2006:3:2020,'ytick',0:8000:40000,'yticklabel',0:8000:40000,'TickDir','out','XTickLabelRotation',0, 'FontName','Times New Roman','FontSize',18);
set(gca,'linewidth',1)
xlabel('Year','FontWeight','bold')
ylabel('Fish quantity (ind)','FontWeight','bold')
set(gca, 'GridColor', [1 1 1], 'GridAlpha', 1, 'GridLineStyle', '-','linewidth',1);
box off
set(gca,'color',[245 245 245]/255)
grid('on');
ax2 = axes('Position',get(gca,'Position'),...
    'Color','none',...
    'XAxisLocation','top',...
    'YAxisLocation','right',...
    'XColor','k','YColor','k','LineWidth',1);
set(ax2,'YTick', []);
set(ax2,'XTick', []);
f1.InvertHardcopy = 'off';
set(f1,'color','w')
